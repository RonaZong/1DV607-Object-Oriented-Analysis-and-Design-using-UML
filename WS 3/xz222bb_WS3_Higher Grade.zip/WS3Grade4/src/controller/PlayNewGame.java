package controller;

public class PlayNewGame {
}
