package BlackJack.model;

public interface ICardObserver {
    void updateNewCard(Card card);
}
