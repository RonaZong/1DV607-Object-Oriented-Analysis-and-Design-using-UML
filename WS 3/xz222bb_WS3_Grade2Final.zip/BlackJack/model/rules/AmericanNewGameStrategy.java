package BlackJack.model.rules;

import BlackJack.model.Deck;
import BlackJack.model.Dealer;
import BlackJack.model.Player;
import BlackJack.model.Card;
public class AmericanNewGameStrategy extends Factory {

  public boolean NewGame(Dealer a_dealer, Player a_player) {

    super.NewGame(a_dealer,a_player);
    a_dealer.getCard(a_dealer, false);

    return true;
  }
}