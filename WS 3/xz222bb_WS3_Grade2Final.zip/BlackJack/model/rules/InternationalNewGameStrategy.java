package BlackJack.model.rules;

import BlackJack.model.Deck;
import BlackJack.model.Dealer;
import BlackJack.model.Player;
import BlackJack.model.Card;
public class InternationalNewGameStrategy extends Factory {

    @Override
    public boolean NewGame(Dealer a_dealer, Player a_player) {
        super.NewGame(a_dealer,a_player);
        return false;
    }
}