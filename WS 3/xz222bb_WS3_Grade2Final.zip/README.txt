# 1DV607

Members of the group for WS3:


Rahim, Pormah, rp222hu
Xiaohe, Zhu, xz222az
Xingrong, Zong, xz222bb

For running this program, please use your command line tool, and go to the path of the file by cd command. Then use java -jar blackjack_java2.jar command to run the program.




