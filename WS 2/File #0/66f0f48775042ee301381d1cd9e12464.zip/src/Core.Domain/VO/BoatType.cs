﻿namespace Core.Domain.VO
{
    public enum BoatType
    {
        Sailboat,
        Motorsailer,
        Kayak,
        Canoe,
        Other
    }
}
