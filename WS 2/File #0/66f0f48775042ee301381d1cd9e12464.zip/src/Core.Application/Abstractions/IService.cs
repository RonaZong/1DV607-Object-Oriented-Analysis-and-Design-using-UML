﻿namespace Core.Application.Abstractions
{
    /// <summary>
    ///     Marker interface for services.
    /// </summary>
    public interface IService
    {
    }
}
