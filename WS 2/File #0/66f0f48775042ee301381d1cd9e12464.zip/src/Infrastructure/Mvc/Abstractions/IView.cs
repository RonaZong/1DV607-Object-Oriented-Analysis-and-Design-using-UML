﻿namespace Infrastructure.Mvc.Abstractions
{
    public interface IView
    {
        void Render();
    }
}
