﻿using System;

namespace Infrastructure.Mvc.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ControllerAttribute : Attribute
    {
    }
}
