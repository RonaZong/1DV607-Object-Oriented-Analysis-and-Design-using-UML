package model;

public class Member {

	
	public String addFirstName(/*controller.User new_user*/) {
		//String firstName = new_user.ScanFirstName();
		String firstName = "Thomas";
		return firstName;
	
	}
	public String addLastName(/*controller.User new_user*/) {
		//String lastName = new_user.ScanLastName();
		String lastName = "Andersson";
		return lastName;
	}
	
	/*public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}*/
}
