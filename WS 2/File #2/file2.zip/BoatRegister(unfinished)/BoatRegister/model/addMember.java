package model;

public class addMember {
	private Member newMember;
	
	public addMember() {
		newMember = new Member();
	}
	
	/*public String setFirstName() {
		return newMember.getFirstName();
	}
	
	public String setLastName() {
		return newMember.getLastName();
	}*/
}
