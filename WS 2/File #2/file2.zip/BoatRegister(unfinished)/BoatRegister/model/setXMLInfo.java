package model;

public class setXMLInfo {

}
