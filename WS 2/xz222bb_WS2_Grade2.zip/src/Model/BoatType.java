package Model;

public enum BoatType {

        SAILBOAT, MOTORSAILOR, KAYAK_OR_CANOE, OTHER

}

