package Util;

public enum UserChoiceInStartMenu {
    ADD_NEW_MEMBER, MEMBER_MENU, SEE_INSTRUCTION, SAVE, QUIT
}
