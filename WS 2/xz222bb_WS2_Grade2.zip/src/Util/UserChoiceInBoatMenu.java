package Util;

public enum UserChoiceInBoatMenu {
    ADD_NEW_BOAT, DELETE_BOAT, CHANGE_BOAT_INFORMATION, GO_BACK

}
