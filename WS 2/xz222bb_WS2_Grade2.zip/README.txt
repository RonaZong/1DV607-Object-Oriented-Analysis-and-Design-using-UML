# 1DV607

This Boat Club is make by Rahim Pormah rp222hu, Xiaohe Zhy xz222az, Xingrong Zong xz222bb.


For running this program, please use your command line tool, and go to the path of the 1DV607.jar file by cd command. Then use java -jar 1DV607.jar command to run the program.


For checking how to run this program, please run the program and go to main menu and press 3 to see the instruction.