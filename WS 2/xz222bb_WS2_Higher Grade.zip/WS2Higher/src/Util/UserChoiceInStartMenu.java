package Util;

public enum UserChoiceInStartMenu {
    ADD_NEW_MEMBER, LOG_IN, MEMBER_MENU, SEE_INSTRUCTION, SEARCH, SAVE, QUIT
}
