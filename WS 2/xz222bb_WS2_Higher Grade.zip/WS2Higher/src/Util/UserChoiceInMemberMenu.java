package Util;

public enum UserChoiceInMemberMenu {

    COMPACT_LIST, VERBOSE_LIST, QUIT, DELETE, UPDATE, SPECIFIC_MEMBER

}
