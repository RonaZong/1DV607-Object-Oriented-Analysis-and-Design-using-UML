Members of the group for WS1:


Katra, Hmidi, kh222yg
Xiaohe, Zhu, xz222az
Xingrong, Zong, xz222bb
